<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body style="background-color: #ffff00;">  
<div class="">
<div class="row text-center">
	  <div style="background-color: #01008a;padding: 20px;">
	  <img width="7%" src="1.png"></div>
</div>
  <div class="row text-center">
  <div class="col-md-3 col-lg-3 col-sm-3 hidden-xs">
  </div>
    <div class="col-md-6 col-lg-6 col-sm-6 col-xs-12">
	<br/><br/>
	<img width="10%" src="2.png"><br/>
      <h3 style="margin-top:50px;color: #283c94;text-transform:uppercase;">thank you for subscribing with<br/>DeddaaBox</h3><br/>
      <div style="padding:20px;background-color: #01008a;">
	  <p style="font-size:15px;text-transform:uppercase;color:#fff;"><span style="font-weight:600;">Transaction ID:</span><span>444444</span></p>
	  	  <p style="font-size:15px;text-transform:uppercase;color:#fff;"><span style="font-weight:600;">Amount:</span><span>444444</span></p>
		  	  <p style="font-size:15px;text-transform:uppercase;color:#fff;"><span style="font-weight:600;">Date:</span><span>444444</span></p>
	  </div><br/>
	        <p style="font-size:20px;">You will recieve an email confirmation with subscription details</p><br/>
				  <button type="button" class="btn btn-warning btn-lg" style="background-color: #01008a;border-color: #01008a;color: #fff;">GO TO HOMEPAGE</button>
				  <br/>
    </div>
	  <div class="col-md-3 col-lg-3 col-sm-3 hidden-xs">
  </div>
  </div>
</div>

</body>
</html>
